/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bropals.lib.simplegame.leveldesigner;

/**
 *
 * @author Jonathon
 */
public enum DragMode {
    RESIZE_TOP, RESIZE_BOTTOM, RESIZE_RIGHT, RESIZE_LEFT, MOVE_DRAG, NONE;
}
